
document.querySelector('button')
    .addEventListener('click', cliclada, false)

    document.querySelector('.refre')
        .addEventListener('click', krik, true)

function cliclada(){
    let nat = document.querySelector('#natu').value
    let hum = document.querySelector('#huma').value
    let cod = document.querySelector('#codi').value
    let mat = document.querySelector('#mate').value
    let red = document.querySelector('#reda').value
    
    document.querySelector('.result').innerHTML = vai(nat, hum, cod, mat, red);
};


function vai(nat, hum, cod, mat, red){
    var tes = 10
    if(parseInt(nat,tes) + parseInt(hum,tes) + parseInt(cod,tes) + parseInt(mat,tes) + parseInt(red,tes) >= 0){
        return parseInt(nat,tes)/5 + parseInt(hum,tes)/5 + parseInt(cod,tes)/5 + parseInt(mat,tes)/5 + parseInt(red,tes)/5
    }
    
    else{
        alert('preencha todos os campos.')
    }
}

function krik(){
    document.location.reload(true);
}

